package kalah.game.model;

public class Store extends Pit {

	public Store(int ownerNum, int index) {
		super(ownerNum, index);
	}
}
