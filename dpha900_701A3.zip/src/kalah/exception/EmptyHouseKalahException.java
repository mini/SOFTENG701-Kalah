package kalah.exception;

public class EmptyHouseKalahException extends RuntimeException {
	private static final long serialVersionUID = -3944041202821191794L;
}
