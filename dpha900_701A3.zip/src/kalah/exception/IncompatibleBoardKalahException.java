package kalah.exception;

public class IncompatibleBoardKalahException extends RuntimeException {
	private static final long serialVersionUID = -6858541357268670795L;

	public IncompatibleBoardKalahException(String message) {
		super(message);
	}
}
